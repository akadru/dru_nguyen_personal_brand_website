# The Front Row Test — v3 Holtom prompt for any AI rollout

Copy-paste prompts from the post: https://drunguyen.me/blog/nightclub-and-ai-adoption

## How to use

1. Open Claude (or ChatGPT, or Gemini).
2. Open the prompt file you want to run.
3. Copy the whole body and paste it into a new conversation.
4. Answer the grounding questions one at a time. Be specific.

## What's in this pack

- `01-the-front-row-test.md` — before any AI rollout, vendor pitch, or tool purchase.

## License

Free to use. If you remix or republish, credit drunguyen.me.
