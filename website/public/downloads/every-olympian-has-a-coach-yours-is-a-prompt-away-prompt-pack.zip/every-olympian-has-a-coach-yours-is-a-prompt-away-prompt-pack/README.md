# Every Olympian has a coach — 5 v3 Holtom prompts

Copy-paste prompts from the post: https://drunguyen.me/blog/every-olympian-has-a-coach-yours-is-a-prompt-away

## How to use

1. Open Claude (or ChatGPT, or Gemini).
2. Open the prompt file you want to run.
3. Copy the whole body and paste it into a new conversation.
4. Answer the grounding questions one at a time. Be specific.

## What's in this pack

- `01-board-of-advisors.md` — any decision you have not yet committed to.
- `02-fractional-cfo.md` — monthly close, or any time runway feels uncertain.
- `03-planning-facilitator.md` — off-sites, quarterly planning, annual reviews.
- `04-monday-accountability.md` — every Monday morning, before Slack.
- `05-pre-mortem.md` — after you have decided. Before you have committed publicly.

## License

Free to use. If you remix or republish, credit drunguyen.me.
